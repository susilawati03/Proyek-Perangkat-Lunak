<!-- jQuery -->
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
       $('.<?php echo isset($active)?$active:'dash';?>').addClass('active');
    });
</script>
<!-- Bootstrap Core JavaScript -->

