<div class="row">
	<div class="col-md-8">
		<table></table>
	</div>
</div>